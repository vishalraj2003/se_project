package Conectors;

import java.util.*;
import java.sql.*;
import com.*;
import java.io.*;
import common.*;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class emailing extends Connect {
	public emailing()
    {
		Connect.connect_mysql();
    }
   public ArrayList listOut() {
	   String error = "";
	   ArrayList resultArray = new ArrayList();
	   try {
		   String SQL = "SELECT * FROM applicant";
		   statement = connection.createStatement();
		   rs = statement.executeQuery(SQL);
		   while(rs.next())
			{		
				HashMap results = new HashMap();
				results.put(rs.getString("applicant_name"),rs.getString("applicant_email"));
				resultArray.add(results);
			}
	   }
	   catch(Exception e){
           StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
       }
	return resultArray;
   }

      public String sendMailNow(String Subject,String dataMessage) {
    	  String msg = null;
    	  // Recipient's email ID needs to be mentioned.
    	  ArrayList<Map> A = new ArrayList();
  		emailing e = new emailing();
  		A = e.listOut();
  		HashMap A1 = new HashMap();
  		for (Map<String, String> entry: A) {
  			for (String key: entry.keySet()) {
  				String value = entry.get(key);
  				//System.out.println("Key= "+key);
  				//System.out.println("Value= "+value);
  		
         String to = value;

         // Sender's email ID needs to be mentioned
         String from = "";//change accordingly
         final String username = "";//change accordingly
         final String password = "";//change accordingly

         // Assuming you are sending email through relay.jangosmtp.net
        
         Properties props = new Properties();    
         props.put("mail.smtp.host", "smtp.gmail.com");    
         props.put("mail.smtp.socketFactory.port", "465");    
         props.put("mail.smtp.socketFactory.class",    
                   "javax.net.ssl.SSLSocketFactory");    
         props.put("mail.smtp.auth", "true");    
         props.put("mail.smtp.port", "465");   
         
         // Get the Session object.
         Session session = Session.getInstance(props,
         new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication(username, password);
            }
         });

         try {
            // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.setRecipients(RecipientType.TO,InternetAddress.parse(to));

            // Set Subject: header field
            message.setSubject(Subject);

            // Now set the actual message
            message.setText(dataMessage.replace("<NAME>", key));

            // Send message
            Transport.send(message);

            msg = "Sent message successfully....";

         } catch (MessagingException e1) {
               throw new RuntimeException(e1);
         }
  			}
  		}
		return msg;
      }
   }
