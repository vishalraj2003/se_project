package Conectors;
import java.lang.Math;   

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
@WebServlet (urlPatterns = "/reset")
public class emailingP extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        final String username = "redhatexam1947@gmail.com";
        final String password = "V12345678";
        final String resetId = req.getParameter("email");
        int min = 1111;
        int max = 9999;
        int b = (int)(Math.random()*(max-min+1)+min);  
        Properties prop = new Properties();
        prop.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        prop.setProperty("mail.smtp.starttls.enable", "true");
        prop.setProperty("mail.smtp.ssl.protocols", "TLSv1.2");
		prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); 
        
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {

            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("redhatexam1947@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(resetId)
            );
            message.setSubject("MyJava testing mail");
            message.setText("Dear Mailer,"
                    + "\n\n Mail sent - code: "+b+"\n\n\n Thank you!!!");

            Transport.send(message);
            PrintWriter out = resp.getWriter();
            resp.setContentType("text/html");
            out.println("<h1>Check your mail</h1>");
            //System.out.println("Done");

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

}