package Conectors;
import java.util.*;
import java.sql.*;
import common.*;
import java.io.*;
public class testingSeat {
	public static void main(String[] args) {
		counterUpdater a = new counterUpdater();
		String x = a.statusFlight(20);
		System.out.println(x);
	}
}
