package Conectors;

import java.util.*;
import java.sql.*;
import common.*;
import java.io.*;

public class counterUpdater extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public counterUpdater()
    {
		Connect.connect_mysql();
    }
	public String statusFlightF(int i,int A) {
		String SQL = "update fight_info set seat_booked = case when date_of_Dept>=curdate() and seat_booked<=total_seat and status='Not departed Flight'  then seat_booked+1 else seat_booked end where flight_id = "+A;
		String error = null;
		
		int count = 0;
		int z = i;
		while(i>0) {
			try {
				pstmt = connection.prepareStatement(SQL);
				count += pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				StringWriter writer = new StringWriter();
				PrintWriter printWriter = new PrintWriter( writer );
				e.printStackTrace( printWriter );
				printWriter.flush();
				String stackTrace = writer.toString();
				error+="Error : "+stackTrace;
				System.out.println(" Error : "+ e.toString());
			}
		i--;
		}
		if (count == 0){
			return "Flight departed or seat is full";
		}
		else {
			counterUpdater a = new counterUpdater();
			a.priceChange();
			return "Your "+count+" seat of First class";
		}
	}
	public String priceChange() {
		String SQL = "update fight_info set first_class =  \r\n"
				+ "case\r\n"
				+ "	when (seat_booked/total_seat)*100>=25 and (seat_booked/total_seat)*100<=50 and status='Not departed Flight' then first_class+first_class*0.09\r\n"
				+ "    when (seat_booked/total_seat)*100>=50 and (seat_booked/total_seat)*100<=75 and status='Not departed Flight' then first_class+first_class*0.04\r\n"
				+ "    when (seat_booked/total_seat)*100>=75 and status='Not departed Flight' then first_class+first_class*0.1\r\n"
				+ "    else first_class\r\n"
				+ "end\r\n"
				+ "    \r\n"
				+ "\r\n";
		String error = null;
		try {
			pstmt = connection.prepareStatement(SQL);
			pstmt.executeUpdate();
			
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
		
	}
	public String statusFlightS(int i,int A) {
		String SQL = "update fight_info set seat_booked = case when date_of_Dept>=curdate() and seat_booked<=total_seat  then seat_booked+1  else seat_booked end where flight_id = "+A;
		String error = null;
		
		int count = 0;
		while(i>0) {
			try {
				pstmt = connection.prepareStatement(SQL);
				count += pstmt.executeUpdate();
			}
			catch(Exception e)
			{
				StringWriter writer = new StringWriter();
				PrintWriter printWriter = new PrintWriter( writer );
				e.printStackTrace( printWriter );
				printWriter.flush();
				String stackTrace = writer.toString();
				error+="Error : "+stackTrace;
				System.out.println(" Error : "+ e.toString());
			}
		i--;
		}
		if (count == 0){
			return "Flight departed or seat is full";
		}
		else {
			counterUpdater a = new counterUpdater();
			a.priceChangeS();
			return "Your "+count+" seat of second class booked";
			
		}
	}
	public String priceChangeS() {
		String SQL = "update fight_info set second_class =  \r\n"
				+ "case\r\n"
				+ "	when (seat_booked/total_seat)*100>=25 and (seat_booked/total_seat)*100<=50 and status='Not departed Flight' then second_class+second_class*0.09\r\n"
				+ "    when (seat_booked/total_seat)*100>=50 and (seat_booked/total_seat)*100<=75 and status='Not departed Flight' then second_class+second_class*0.04\r\n"
				+ "    when (seat_booked/total_seat)*100>=75 and status='Not departed Flight' then second_class+second_class*0.1\r\n"
				+ "    else second_class\r\n"
				+ "end\r\n"
				+ "    \r\n"
				+ "\r\n";
		String error = null;
		try {
			pstmt = connection.prepareStatement(SQL);
			pstmt.executeUpdate();
			
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
		
	}
	
}
