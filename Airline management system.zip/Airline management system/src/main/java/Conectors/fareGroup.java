package Conectors;

import java.util.*;
import java.sql.*;
import common.*;
import java.io.*;

public class fareGroup extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public fareGroup()
    {
		Connect.connect_mysql();
    }
	////////////////Function for getting all the Airport Details////////////////////  
	public ArrayList getAllApplicant()
	{
	String SQL = "SELECT * FROM citizen_card_system.fight_info;";
	int count=0;
	ArrayList resultArray = new ArrayList();
	try
	{
	statement = connection.createStatement();
	rs = statement.executeQuery(SQL);
	while(rs.next())
	{		
		HashMap results = new HashMap();
		results.put("id",rs.getString("id"));
		results.put("flight_id",rs.getInt("flight_id"));
		results.put("flight_name",rs.getString("flight_name"));
		results.put("date_of_Dept",rs.getString("date_of_Dept"));
		results.put("seat_booked",rs.getString("seat_booked"));
		results.put("total_seat",rs.getString("total_seat"));
		results.put("status",rs.getString("status"));
		results.put("first_class",rs.getString("first_class"));
		results.put("second_class",rs.getString("second_class"));
		count++;
	    resultArray.add(results);
	}
	}
	catch(Exception e)
	{
		System.out.println("Error is: "+ e);
	}
	return resultArray;
	}
	public String statusFlight() {
		fareGroup applicantDetails = new fareGroup();
		ArrayList allApplicant = applicantDetails.getAllApplicant();
		String sql = "update fight_info set status =  CASE when date_of_Dept>=curdate() then 'Not departed Flight' else 'Departed Flight' end";
		String error = null;
		try {
			pstmt = connection.prepareStatement(sql);
			pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
//		public String statusFlight() {
//			
//		}
	}
	
}
