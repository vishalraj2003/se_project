package Conectors;
import Conectors.*;
import java.util.*;
import java.sql.*;
import com.*;
import java.io.*;
import common.*;
public class testing {

	public static void main(String[] args) {
		ArrayList<Map> A = new ArrayList();
		emailing e = new emailing();
		A = e.listOut();
		HashMap A1 = new HashMap();
		for (Map<String, String> entry: A) {
			for (String key: entry.keySet()) {
				String value = entry.get(key);
				System.out.println("Key= "+key);
				System.out.println("Value= "+value);
			}
		}
		//System.out.println(A[0]);
		
		String result = e.sendMailNow("testing","First mail testing for se project");
		System.out.println(result);
	}

}
