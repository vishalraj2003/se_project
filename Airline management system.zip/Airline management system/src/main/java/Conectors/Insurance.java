package Conectors;

import java.util.*;
import java.sql.*;
import com.*;
import java.io.*;
import common.*;
public class Insurance extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public Insurance()
    {
		Connect.connect_mysql();
    }
	//////////Save User Details /////
	public String saveInsurance(HashMap insuranceData)
	{
		String SQL = "INSERT INTO `insurance` (`insurance_applicant_id`, `insurance_number`, `insurance_type`, `insurance_amount`, `insurance_valid_from`, `insurance_valid_till`, `insurance_description`) VALUES (?, ?, ?, ?, ?, ?, ?);";
		int record=0; 
		String error = "";
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) insuranceData.get("insurance_applicant_id"));
			pstmt.setString(2,(String) insuranceData.get("insurance_number"));
			pstmt.setString(3,(String) insuranceData.get("insurance_type"));
			pstmt.setString(4,(String) insuranceData.get("insurance_amount"));
			pstmt.setString(5,(String) insuranceData.get("insurance_valid_from"));
			pstmt.setString(6,(String) insuranceData.get("insurance_valid_till"));
			pstmt.setString(7,(String) insuranceData.get("insurance_description"));
			
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	//////////////////Function for getting Users Details//////////	
    public HashMap getInsuranceDetails(int insurance_id)
	{
        HashMap results = new HashMap();
        int count=0;
		try
		{
			String SQL = "SELECT * FROM `insurance` WHERE insurance_id = "+insurance_id ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				results.put("insurance_applicant_id",Integer.parseInt(rs.getString("insurance_applicant_id")));
				results.put("insurance_number",rs.getString("insurance_number"));
				results.put("insurance_type",Integer.parseInt(rs.getString("insurance_type")));
				results.put("insurance_amount",rs.getString("insurance_amount"));
				results.put("insurance_valid_from",rs.getString("insurance_valid_from"));
				results.put("insurance_valid_till",rs.getString("insurance_valid_till"));
				results.put("insurance_description",rs.getString("insurance_description"));
				count++;
            }
			if(count==0)
			{
				results.put("insurance_applicant_id",0);
				results.put("insurance_number","");
				results.put("insurance_id","");
				results.put("insurance_type",0);
				results.put("insurance_amount","");
				results.put("insurance_valid_from","");
				results.put("insurance_valid_till","");
				results.put("insurance_description","");
			}
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return results;
    }
    /// Update the Insurance ////
	public String updateInsurance(HashMap insuranceData)
	{
		String SQL = "UPDATE `insurance` SET `insurance_applicant_id` = ?, `insurance_number` = ?, `insurance_type` = ?, `insurance_amount` = ?, `insurance_valid_from` = ?, `insurance_valid_till` = ?, `insurance_description` = ? WHERE `insurance_id` = ?;";
		String error = "";
		
		int record=0;	
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) insuranceData.get("insurance_applicant_id"));
			pstmt.setString(2,(String) insuranceData.get("insurance_number"));
			pstmt.setString(3,(String) insuranceData.get("insurance_type"));
			pstmt.setString(4,(String) insuranceData.get("insurance_amount"));
			pstmt.setString(5,(String) insuranceData.get("insurance_valid_from"));
			pstmt.setString(6,(String) insuranceData.get("insurance_valid_till"));
			pstmt.setString(7,(String) insuranceData.get("insurance_description"));
			pstmt.setString(8,(String) insuranceData.get("insurance_id"));
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	
	////////////////Function for getting all the Airport Details////////////////////  
    public ArrayList getAllInsurance(int type)
	{
		String SQL = "SELECT * FROM `insurance`, `type`, `applicant` WHERE insurance_applicant_id = applicant_id AND insurance_type = type_id";
		if(type != 0)
			SQL = "SELECT * FROM `insurance`, `type`, `applicant` WHERE insurance_applicant_id = applicant_id AND insurance_type = type_id AND applicant_id = "+type;
		int count=0;
        ArrayList resultArray = new ArrayList();
        try
		{
			statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{		
				HashMap results = new HashMap();
				results.put("insurance_applicant_id",rs.getString("insurance_applicant_id"));
				results.put("insurance_number",rs.getString("insurance_number"));
				results.put("type_name",rs.getString("type_name"));
				results.put("insurance_type",rs.getString("insurance_type"));
				results.put("insurance_amount",rs.getString("insurance_amount"));
				results.put("insurance_valid_from",rs.getString("insurance_valid_from"));
				results.put("insurance_valid_till",rs.getString("insurance_valid_till"));
				results.put("insurance_description",rs.getString("insurance_description"));
				results.put("insurance_id",rs.getString("insurance_id"));	
				results.put("applicant_name",rs.getString("applicant_name"));
				results.put("applicant_mobile",rs.getString("applicant_mobile"));
				results.put("applicant_email",rs.getString("applicant_email"));
				results.put("applicant_password",rs.getString("applicant_password"));
				results.put("applicant_address",rs.getString("applicant_address"));
				results.put("applicant_city",rs.getString("applicant_city"));
				results.put("applicant_state",Integer.parseInt(rs.getString("applicant_state")));
				results.put("applicant_pincode",rs.getString("applicant_pincode"));	
				results.put("applicant_id",rs.getString("applicant_id"));
				results.put("applicant_passport_no",rs.getString("applicant_passport_no"));
				results.put("applicant_passport_city",rs.getString("applicant_passport_city"));
				results.put("applicant_passport_date",rs.getString("applicant_passport_date"));
				results.put("applicant_expiry_date",rs.getString("applicant_expiry_date"));
				results.put("applicant_documents",rs.getString("applicant_documents"));	
				results.put("applicant_tours",rs.getString("applicant_tours"));		
						
				count++;
                resultArray.add(results);
            }
         }
		catch(Exception e)
		{
            System.out.println("Error is: "+ e);
        }
        return resultArray;
    }
	/////Function for Getting the List////////////
	public String getApplicantOption(Integer SelID)
    {
		int selectedID = SelID.intValue();
    	return Connect.getOptionList("applicant","applicant_id","applicant_name","applicant_id,applicant_name",selectedID,"1");
    }
	/////Function for Getting the List////////////
	public String getInsuranceOption(Integer SelID)
    {
		int selectedID = SelID.intValue();
    	return Connect.getOptionList("type","type_id","type_name","type_id,type_name",selectedID,"1");
    }
}
